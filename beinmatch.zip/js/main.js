$(document).ready(function () {
    
    $('.burger-menu').on('click', e => {
        $('.nav-links').toggleClass('nav-links-active');
        
    });
});

